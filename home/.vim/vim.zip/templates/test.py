from Cheetah.Template import Template
template = Template(file = "pyheader.tmpl")
print template.respond()
